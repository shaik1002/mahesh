﻿namespace PROPERTYRENTALPORTALAPI.Models.Domain
{
    public class AppSettings
    {
        public string JWTSecret { get; set; }
    }
}
