
## Getting Started

1. Install packages

```
yarn
```

2. Run project

```
yarn start
```



## Technology Stack

- Bootstrap 5
- Angular 18

