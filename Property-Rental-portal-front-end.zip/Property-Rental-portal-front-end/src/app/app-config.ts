export class BerryConfig {
  static isCollapse_menu: boolean = false;
  static font_family: string = 'Roboto'; // Roboto, poppins, inter
}
