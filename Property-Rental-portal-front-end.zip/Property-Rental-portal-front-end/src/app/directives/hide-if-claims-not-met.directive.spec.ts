import { HideIfClaimsNotMetDirective } from './hide-if-claims-not-met.directive';

describe('HideIfClaimsNotMetDirective', () => {
  it('should create an instance', () => {
    const directive = new HideIfClaimsNotMetDirective();
    expect(directive).toBeTruthy();
  });
});
